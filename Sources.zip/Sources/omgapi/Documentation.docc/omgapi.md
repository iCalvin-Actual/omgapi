# ``omgapi``

Swift wrapper to api.omg.lol

## What is omgapi and/or omg.lol

[omg.lol](https://home.omg.lol/referred-by/app) offers personal web tools like profiles, status updates, now pages, and more — all tied to your unique address. Even if you don't have an address you van view public content from the omg.lol community. This Swift wrapper provides convenient, type-safe access to [api.omg.lol](https://api.omg.lol), making it easy to build native apps and tools around the service.

## Who makes this

Hi! I'm Calvin :wave: I made an [app client to omg.lol]() and overoptimized this API Package, figured I'd might as well make it public. 

See omg.lol for more about the service. Please note that this is an unofficial third party SDK, while it could not have been possible without the documentation at api.omg.lol and Email/Discord support from the community, this API is officially not related to the omg.lol team and exists as a token of appreciation.

## Where does this data come from

Everything in the `omg.lol` is owned/published by a paid Address on the service and hosted by omg.lol. All published resources can either be made public or private by the owner of that Address. omgapi allows access to public data, but also allows the client to request/provide an API Credential from omg.lol to view private data or post/edit content on the service. omgapi takes no responsability for the content hosted by the omg.lol service.

## Geting started

To start working with omgapi, all you need to do is create an instance of the api. 
```
let client = api()
```
The api is stateless, and takes no parameters. You don't need to authenticate, just start making requests.
```
async let info = try client.serviceInfo()
```

All functions in the api are async and will throw an ``APIError`` if it runs into an issue. Make sure to properly catch errors.
```
do {
  async let profile = try client.publicProfile(searchAddress)
  searchAddressExists = true
}
catch {
  switch error as? APIError {
  case .notFound: searchAddressExists = false
  default:  throw error
  }
}
```

## Topics

### Essentials

`api` is the gateway to, well, the api. Everything.

- ``api``
- <doc:APIError>
- <doc:Address>
- ``AddressInfo``

### Public Feeds

omg.lol and omgapi are built on top of the web, with publisher controlled access levels

- <doc:Directory>
- ``NowGarden``
- ``StatusLog``
- <doc:PicsFeed>

### Address Pages

View public web page data for any AddressName

- ``PublicProfile``
- ``NowPage``

### Statuses

Share moments and follow others without algorithms

- ``StatusLog``
- ``PublicLog``
- <doc:Following>

### Acting on a user's behalf

Edit and post content. Access private data. 

- <doc:Authentication>
- <doc:Posting>

### More Address Content

- ``PURLs``
- ``PasteBin``

### Structures

- ``Profile``
- ``Now``
- ``PURL``
- ``Paste``
- ``Status``
- ``Pic``
