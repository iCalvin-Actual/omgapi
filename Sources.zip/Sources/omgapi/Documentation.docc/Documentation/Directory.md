#  Directory

Reading public address data from omg.lol address directory

If a user chooses to make an omg.lol address Public it will be exposed in the omg.lol Directory, which is exposed by the api with the `api.addressDirectory()` function. These resources will tell you more about working with the Address Directory and getting public data about an address.

Recent public user activity is also highlighted in the ``NowGarden``, ``StatusLog``, and `<doc:PicsFeed`>

