#  ``APICredential``

Simple typealias around `String` to let us be more clear about when we're expecting an API Credential string in a parameter

