#  ``PublicProfile``

Representation of an AddressName's public profile webpage

Display content from the Address' main landing page. Basically what you'd see if you visited address.omg.lol in your browser, but represented as a Swift model (wrapping html string content)
