# Address

Exposes public meta-data about an Address on omg.lol

## Topics

### Properties

- ``name``
- ``registered``
- ``expired``
- ``verified``
