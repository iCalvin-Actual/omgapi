#  ``TimeStamp``

Represents the api.omg.lol's own timestamp value which prefers to expose a `unixEpochTime` value

## Topics

### Properties

- ``now``
- ``date``
- ``message``

### Codable

- ``init(from:)``
- ``encode(to:)``


